package geektime.spring.springbucks.waiterservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaiterServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
